import{c}from"./index-DJIrW-TQ.js";/**
 * @license lucide-react v0.473.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],i=c("Clock",o);export{i as C};
//# sourceMappingURL=clock-Bx8kqVKW.js.map
